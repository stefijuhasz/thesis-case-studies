package org.yakindu.scr.monitor;

public class MonitorStatemachine implements IMonitorStatemachine {

	protected class SCILightInputsImpl implements SCILightInputs {
	
		private boolean displayRed;
		
		public void raiseDisplayRed() {
			displayRed = true;
		}
		
		private boolean displayGreen;
		
		public void raiseDisplayGreen() {
			displayGreen = true;
		}
		
		private boolean displayYellow;
		
		public void raiseDisplayYellow() {
			displayYellow = true;
		}
		
		private boolean displayNone;
		
		public void raiseDisplayNone() {
			displayNone = true;
		}
		
		protected void clearEvents() {
			displayRed = false;
			displayGreen = false;
			displayYellow = false;
			displayNone = false;
		}
	}
	
	protected SCILightInputsImpl sCILightInputs;
	
	private boolean initialized = false;
	
	public enum State {
		main_region_Other,
		main_region_Green,
		main_region_Error,
		main_region_Red,
		$NullState$
	};
	
	private final State[] stateVector = new State[1];
	
	private int nextStateIndex;
	
	
	
	public MonitorStatemachine() {
		sCILightInputs = new SCILightInputsImpl();
	}
	
	public void init() {
		this.initialized = true;
		
		for (int i = 0; i < 1; i++) {
			stateVector[i] = State.$NullState$;
		}
		clearEvents();
		clearOutEvents();
	}
	
	public void enter() {
		if (!initialized) {
			throw new IllegalStateException(
					"The state machine needs to be initialized first by calling the init() function.");
		}
	
		enterSequence_main_region_default();
	}
	
	public void exit() {
		exitSequence_main_region();
	}
	
	/**
	 * @see IStatemachine#isActive()
	 */
	public boolean isActive() {
		return stateVector[0] != State.$NullState$;
	}
	
	/** 
	* Always returns 'false' since this state machine can never become final.
	*
	* @see IStatemachine#isFinal()
	*/
	public boolean isFinal() {
		return false;
	}
	/**
	* This method resets the incoming events (time events included).
	*/
	protected void clearEvents() {
		sCILightInputs.clearEvents();
	}
	
	/**
	* This method resets the outgoing events.
	*/
	protected void clearOutEvents() {
	}
	
	/**
	* Returns true if the given state is currently active otherwise false.
	*/
	public boolean isStateActive(State state) {
	
		switch (state) {
		case main_region_Other:
			return stateVector[0] == State.main_region_Other;
		case main_region_Green:
			return stateVector[0] == State.main_region_Green;
		case main_region_Error:
			return stateVector[0] == State.main_region_Error;
		case main_region_Red:
			return stateVector[0] == State.main_region_Red;
		default:
			return false;
		}
	}
	
	public SCILightInputs getSCILightInputs() {
		return sCILightInputs;
	}
	
	private boolean check_main_region_Other_tr0_tr0() {
		return sCILightInputs.displayGreen;
	}
	
	private boolean check_main_region_Other_tr1_tr1() {
		return sCILightInputs.displayRed;
	}
	
	private boolean check_main_region_Green_tr0_tr0() {
		return sCILightInputs.displayGreen;
	}
	
	private boolean check_main_region_Green_tr1_tr1() {
		return sCILightInputs.displayRed;
	}
	
	private boolean check_main_region_Green_tr2_tr2() {
		return sCILightInputs.displayNone;
	}
	
	private boolean check_main_region_Green_tr3_tr3() {
		return sCILightInputs.displayYellow;
	}
	
	private boolean check_main_region_Red_tr0_tr0() {
		return sCILightInputs.displayGreen;
	}
	
	private boolean check_main_region_Red_tr1_tr1() {
		return sCILightInputs.displayRed;
	}
	
	private boolean check_main_region_Red_tr2_tr2() {
		return sCILightInputs.displayNone;
	}
	
	private boolean check_main_region_Red_tr3_tr3() {
		return sCILightInputs.displayYellow;
	}
	
	private void effect_main_region_Other_tr0() {
		exitSequence_main_region_Other();
		enterSequence_main_region_Green_default();
	}
	
	private void effect_main_region_Other_tr1() {
		exitSequence_main_region_Other();
		enterSequence_main_region_Red_default();
	}
	
	private void effect_main_region_Green_tr0() {
		exitSequence_main_region_Green();
		enterSequence_main_region_Error_default();
	}
	
	private void effect_main_region_Green_tr1() {
		exitSequence_main_region_Green();
		enterSequence_main_region_Red_default();
	}
	
	private void effect_main_region_Green_tr2() {
		exitSequence_main_region_Green();
		enterSequence_main_region_Other_default();
	}
	
	private void effect_main_region_Green_tr3() {
		exitSequence_main_region_Green();
		enterSequence_main_region_Other_default();
	}
	
	private void effect_main_region_Red_tr0() {
		exitSequence_main_region_Red();
		enterSequence_main_region_Green_default();
	}
	
	private void effect_main_region_Red_tr1() {
		exitSequence_main_region_Red();
		enterSequence_main_region_Error_default();
	}
	
	private void effect_main_region_Red_tr2() {
		exitSequence_main_region_Red();
		enterSequence_main_region_Other_default();
	}
	
	private void effect_main_region_Red_tr3() {
		exitSequence_main_region_Red();
		enterSequence_main_region_Other_default();
	}
	
	/* 'default' enter sequence for state Other */
	private void enterSequence_main_region_Other_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_Other;
	}
	
	/* 'default' enter sequence for state Green */
	private void enterSequence_main_region_Green_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_Green;
	}
	
	/* 'default' enter sequence for state Error */
	private void enterSequence_main_region_Error_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_Error;
	}
	
	/* 'default' enter sequence for state Red */
	private void enterSequence_main_region_Red_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_Red;
	}
	
	/* 'default' enter sequence for region main_region */
	private void enterSequence_main_region_default() {
		react_main_region__entry_Default();
	}
	
	/* Default exit sequence for state Other */
	private void exitSequence_main_region_Other() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state Green */
	private void exitSequence_main_region_Green() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state Error */
	private void exitSequence_main_region_Error() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state Red */
	private void exitSequence_main_region_Red() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for region main_region */
	private void exitSequence_main_region() {
		switch (stateVector[0]) {
		case main_region_Other:
			exitSequence_main_region_Other();
			break;
		case main_region_Green:
			exitSequence_main_region_Green();
			break;
		case main_region_Error:
			exitSequence_main_region_Error();
			break;
		case main_region_Red:
			exitSequence_main_region_Red();
			break;
		default:
			break;
		}
	}
	
	/* The reactions of state Other. */
	private void react_main_region_Other() {
		if (check_main_region_Other_tr0_tr0()) {
			effect_main_region_Other_tr0();
		} else {
			if (check_main_region_Other_tr1_tr1()) {
				effect_main_region_Other_tr1();
			}
		}
	}
	
	/* The reactions of state Green. */
	private void react_main_region_Green() {
		if (check_main_region_Green_tr0_tr0()) {
			effect_main_region_Green_tr0();
		} else {
			if (check_main_region_Green_tr1_tr1()) {
				effect_main_region_Green_tr1();
			} else {
				if (check_main_region_Green_tr2_tr2()) {
					effect_main_region_Green_tr2();
				} else {
					if (check_main_region_Green_tr3_tr3()) {
						effect_main_region_Green_tr3();
					}
				}
			}
		}
	}
	
	/* The reactions of state Error. */
	private void react_main_region_Error() {
	}
	
	/* The reactions of state Red. */
	private void react_main_region_Red() {
		if (check_main_region_Red_tr0_tr0()) {
			effect_main_region_Red_tr0();
		} else {
			if (check_main_region_Red_tr1_tr1()) {
				effect_main_region_Red_tr1();
			} else {
				if (check_main_region_Red_tr2_tr2()) {
					effect_main_region_Red_tr2();
				} else {
					if (check_main_region_Red_tr3_tr3()) {
						effect_main_region_Red_tr3();
					}
				}
			}
		}
	}
	
	/* Default react sequence for initial entry  */
	private void react_main_region__entry_Default() {
		enterSequence_main_region_Other_default();
	}
	
	public void runCycle() {
		if (!initialized)
			throw new IllegalStateException(
					"The state machine needs to be initialized first by calling the init() function.");
		clearOutEvents();
		for (nextStateIndex = 0; nextStateIndex < stateVector.length; nextStateIndex++) {
			switch (stateVector[nextStateIndex]) {
			case main_region_Other:
				react_main_region_Other();
				break;
			case main_region_Green:
				react_main_region_Green();
				break;
			case main_region_Error:
				react_main_region_Error();
				break;
			case main_region_Red:
				react_main_region_Red();
				break;
			default:
				// $NullState$
			}
		}
		clearEvents();
	}
}
