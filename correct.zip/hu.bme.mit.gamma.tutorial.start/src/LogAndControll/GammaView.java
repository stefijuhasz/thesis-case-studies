package LogAndControll;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.tree.DefaultTreeModel;

import CreateUML.CreateXML;

import javax.swing.tree.DefaultMutableTreeNode;

public class GammaView {
   private JFrame mainFrame;
   public JButton startButton;
   public JButton continueButton;
   public JButton stopButton;

   private JLabel logMessageLabel;
   private JLabel firstLabel;
   private JLabel firstLabel_1;
   private JLabel firstLabel_2;
   private JLabel secondLabel;
   private JLabel secondLabel_1;
   private JLabel secondLabel_2;
   private JLabel thirdLabel;
   private JLabel thirdLabel_1;
   private JLabel thirdLabel_2;
   
   public JPanel firstPanel;
   public JPanel secondPanel;
   public JPanel thirdPanel;
   
   public GammaView(){
      prepareGUI();
   }
   
   /** preparing the UI*/
   private void prepareGUI(){
      mainFrame = new JFrame("GammaGui");
      mainFrame.setSize(1300,740);
      
      JPanel panel = new JPanel();
      panel.setBorder(BorderFactory.createEtchedBorder());
      
      JPanel panel_1 = new JPanel();
      panel_1.setBorder(BorderFactory.createEtchedBorder());
      
      JPanel panel_2 = new JPanel();
      panel_2.setBorder(BorderFactory.createEtchedBorder());
      
      JPanel panel_3 = new JPanel();
      panel_3.setBorder(BorderFactory.createEtchedBorder());
      
      JPanel panel_4 = new JPanel();
      panel_4.setBorder(BorderFactory.createEtchedBorder());
      GroupLayout groupLayout = new GroupLayout(mainFrame.getContentPane());
      groupLayout.setHorizontalGroup(
      	groupLayout.createParallelGroup(Alignment.TRAILING)
      		.addGroup(groupLayout.createSequentialGroup()
      			.addContainerGap()
      			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
      				.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 1264, Short.MAX_VALUE)
      				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 1264, Short.MAX_VALUE)
      				.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 1264, Short.MAX_VALUE)
      				.addComponent(panel_3, GroupLayout.PREFERRED_SIZE, 1264, Short.MAX_VALUE)
      				.addComponent(panel_4, GroupLayout.PREFERRED_SIZE, 1264, Short.MAX_VALUE))
      			.addContainerGap())
      );
      groupLayout.setVerticalGroup(
      	groupLayout.createParallelGroup(Alignment.LEADING)
      		.addGroup(groupLayout.createSequentialGroup()
      			.addContainerGap()
      			.addComponent(panel, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addComponent(panel_3, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addComponent(panel_4, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
      			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      );
      
      JLabel lblNewLabel_9 = new JLabel("LogMessages");
      
      logMessageLabel = new JLabel("LogMessage");
      GroupLayout gl_panel_3 = new GroupLayout(panel_3);
      gl_panel_3.setHorizontalGroup(
      	gl_panel_3.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel_3.createSequentialGroup()
      			.addContainerGap()
      			.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
      				.addComponent(logMessageLabel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 1240, Short.MAX_VALUE)
      				.addComponent(lblNewLabel_9))
      			.addContainerGap())
      );
      gl_panel_3.setVerticalGroup(
      	gl_panel_3.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel_3.createSequentialGroup()
      			.addContainerGap()
      			.addComponent(lblNewLabel_9)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addComponent(logMessageLabel, GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
      			.addContainerGap())
      );
      panel_3.setLayout(gl_panel_3);
      
      thirdLabel = new JLabel("ThirdLabel");
      
      thirdPanel = new JPanel();
      
      thirdLabel_1 = new JLabel("New label");
      
      thirdLabel_2 = new JLabel("New label");
      GroupLayout gl_panel_2 = new GroupLayout(panel_2);
      gl_panel_2.setHorizontalGroup(
      	gl_panel_2.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel_2.createSequentialGroup()
      			.addContainerGap()
      			.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING, false)
      				.addComponent(thirdPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      				.addComponent(thirdLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
      			.addGap(18)
      			.addComponent(thirdLabel_1, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addGap(18)
      			.addComponent(thirdLabel_2, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addContainerGap(815, Short.MAX_VALUE))
      );
      gl_panel_2.setVerticalGroup(
      	gl_panel_2.createParallelGroup(Alignment.TRAILING)
      		.addGroup(gl_panel_2.createSequentialGroup()
      			.addContainerGap()
      			.addComponent(thirdLabel)
      			.addPreferredGap(ComponentPlacement.RELATED)
      			.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING)
      				.addComponent(thirdLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
      				.addComponent(thirdLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
      				.addComponent(thirdPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
      			.addContainerGap())
      );
      panel_2.setLayout(gl_panel_2);
      
      secondLabel = new JLabel("SecondLabel");
      
      secondPanel = new JPanel();
      
      secondLabel_1 = new JLabel("New label");
      
      secondLabel_2 = new JLabel("New label");
      GroupLayout gl_panel_1 = new GroupLayout(panel_1);
      gl_panel_1.setHorizontalGroup(
      	gl_panel_1.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel_1.createSequentialGroup()
      			.addContainerGap()
      			.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
      				.addComponent(secondPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      				.addComponent(secondLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
      			.addGap(18)
      			.addComponent(secondLabel_1, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addGap(18)
      			.addComponent(secondLabel_2, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addContainerGap(629, Short.MAX_VALUE))
      );
      gl_panel_1.setVerticalGroup(
      	gl_panel_1.createParallelGroup(Alignment.TRAILING)
      		.addGroup(gl_panel_1.createSequentialGroup()
      			.addContainerGap()
      			.addComponent(secondLabel)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
      				.addComponent(secondLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
      				.addComponent(secondLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
      				.addComponent(secondPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE))
      			.addContainerGap())
      );
      panel_1.setLayout(gl_panel_1);
      
      firstLabel = new JLabel("FirtsLabel");
      
      firstPanel = new JPanel();
      
      firstLabel_1 = new JLabel("New label");
      
      firstLabel_2 = new JLabel("New label");
      GroupLayout gl_panel = new GroupLayout(panel);
      gl_panel.setHorizontalGroup(
      	gl_panel.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel.createSequentialGroup()
      			.addContainerGap()
      			.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
      				.addComponent(firstLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      				.addComponent(firstPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
      			.addGap(18)
      			.addComponent(firstLabel_1, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addGap(18)
      			.addComponent(firstLabel_2, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
      			.addContainerGap(678, Short.MAX_VALUE))
      );
      gl_panel.setVerticalGroup(
      	gl_panel.createParallelGroup(Alignment.LEADING)
      		.addGroup(gl_panel.createSequentialGroup()
      			.addContainerGap()
      			.addComponent(firstLabel)
      			.addPreferredGap(ComponentPlacement.UNRELATED)
      			.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
      				.addComponent(firstLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      				.addComponent(firstLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      				.addComponent(firstPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
      			.addContainerGap(13, Short.MAX_VALUE))
      );
      firstPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
      panel.setLayout(gl_panel);
      GridBagLayout gbl_panel_4 = new GridBagLayout();
      gbl_panel_4.columnWidths = new int[]{89, 0, 89, 0,89, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
      gbl_panel_4.rowHeights = new int[]{23, 0, 0};
      gbl_panel_4.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
      gbl_panel_4.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
      panel_4.setLayout(gbl_panel_4);
      
      JTree tree = new JTree();
      tree.setBackground(UIManager.getColor("Panel.background"));
      tree.setModel(new DefaultTreeModel(
      	new DefaultMutableTreeNode("Contoller") {
      		{
      			add(new DefaultMutableTreeNode("PriorityTrafficLight"));
      			add(new DefaultMutableTreeNode("SecondaryTrafficlight"));
      		}
      	}
      ));
      GridBagConstraints gbc_tree = new GridBagConstraints();
      gbc_tree.gridheight = 2;
      gbc_tree.fill = GridBagConstraints.VERTICAL;
      gbc_tree.gridx = 15;
      gbc_tree.gridy = 0;
      panel_4.add(tree, gbc_tree);
      
      startButton = new JButton("Start");
      GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
      gbc_btnNewButton.anchor = GridBagConstraints.WEST;
      gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
      gbc_btnNewButton.gridx = 1;
      gbc_btnNewButton.gridy = 1;
      panel_4.add(startButton, gbc_btnNewButton);
      
      continueButton = new JButton("Continue");
      continueButton.setEnabled(false);
      GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
      gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);
      gbc_btnNewButton_1.anchor = GridBagConstraints.WEST;
      gbc_btnNewButton_1.gridx = 3;
      gbc_btnNewButton_1.gridy = 1;
      panel_4.add(continueButton, gbc_btnNewButton_1);
      
      stopButton = new JButton("Stop");
      stopButton.setEnabled(false);
      GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
      gbc_btnNewButton_2.insets = new Insets(0, 0, 0, 5);
      gbc_btnNewButton_2.gridx = 5;
      gbc_btnNewButton_2.gridy = 1;
      panel_4.add(stopButton, gbc_btnNewButton_2);
      mainFrame.getContentPane().setLayout(groupLayout);
      
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
        	new CreateXML().start();
            System.exit(0);
         }        
      });
   }
   
   public void setLog(String message) {
	   logMessageLabel.setText(message);
   }
   
   public void setFirtsLabel(String text) {
	   firstLabel.setText(text);	   
   }
   
   public void setFirstLabel1(String text) {
	   firstLabel_1.setText(text);
   }
   
   public void setFirstLabel2(String text) {
	   firstLabel_2.setText(text);
   }
   
   public void setSecondLabel(String text) {
	   secondLabel.setText(text);	   
   }
   
   public void setSecondLabel1(String text) {
	   secondLabel_1.setText(text);
   }
   
   public void setSecondLabel2(String text) {
	   secondLabel_2.setText(text);
   }
   
   public void setThirdLabel(String text) {
	   thirdLabel.setText(text);	   
   }
   
   public void setThirdLabel1(String text) {
	   thirdLabel_1.setText(text);
   }
   
   public void setThirdLabel2(String text) {
	   thirdLabel_2.setText(text);
   }


   
   public void showEventDemo(){

      mainFrame.setVisible(true);  
   }
}