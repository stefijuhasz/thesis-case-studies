package hu.bme.mit.gamma.impl.controller;

import java.util.Queue;
import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;

import hu.bme.mit.gamma.impl.event.*;
import hu.bme.mit.gamma.impl.interfaces.*;
import hu.bme.mit.gamma.impl.logandcontrol.Loging;

import org.yakindu.scr.controller.IControllerStatemachine.SCISecondaryPoliceListener;
import org.yakindu.scr.controller.IControllerStatemachine.SCIPriorityControlListener;
import org.yakindu.scr.controller.IControllerStatemachine.SCISecondaryControlListener;
import org.yakindu.scr.controller.IControllerStatemachine.SCIPriorityPoliceListener;
import org.yakindu.scr.TimerService;
import org.yakindu.scr.ITimer;
import org.yakindu.scr.controller.ControllerStatemachine;
import org.yakindu.scr.controller.ControllerStatemachine.State;

public class ControllerStatechart implements ControllerStatechartInterface {
	// The wrapped Yakindu statemachine
	private ControllerStatemachine controllerStatemachine = new ControllerStatemachine();
	// Port instances
	private SecondaryPolice secondaryPolice = new SecondaryPolice();
	private PriorityControl priorityControl = new PriorityControl();
	private SecondaryControl secondaryControl = new SecondaryControl();
	private PoliceInterrupt policeInterrupt = new PoliceInterrupt();
	private PriorityPolice priorityPolice = new PriorityPolice();
	// Indicates which queues are active in this cycle
	private boolean insertQueue = true;
	private boolean processQueue = false;
	// Event queues for the synchronization of statecharts
	private Queue<Event> eventQueue1 = new LinkedList<Event>();
	private Queue<Event> eventQueue2 = new LinkedList<Event>();
	
	private String name;
	private Loging l;
	
	private String messages = "";
	private String sender = null;
	
	private LinkedList<String> senders = new LinkedList<String>();
	private LinkedList<String []> receivers = new LinkedList<String[]>();
	
	private LinkedList<String> send = new LinkedList<String>();
	
	public ControllerStatechart(String n) {
		// Initializing and entering the wrapped statemachine
		name = n;
		controllerStatemachine.setTimer(new TimerService());
	}
	
	/** Resets the statemachine. Should be used only be the container (composite system) class. */
	@Override
	public void reset() {
		controllerStatemachine.init();
		controllerStatemachine.enter();
	}
	
	/** Changes the event queues of the component instance. Should be used only be the container (composite system) class. */
	public void changeEventQueues() {
		insertQueue = !insertQueue;
		processQueue = !processQueue;
	}
	
	/** Changes the event queues to which the events are put. Should be used only be a cascade container (composite system) class. */
	public void changeInsertQueue() {
	    insertQueue = !insertQueue;
	}
	
	/** Returns whether the eventQueue containing incoming messages is empty. Should be used only be the container (composite system) class. */
	public boolean isEventQueueEmpty() {
		return getInsertQueue().isEmpty();
	}
	
	/** Returns the event queue into which events should be put in the particular cycle. */
	private Queue<Event> getInsertQueue() {
		if (insertQueue) {
			return eventQueue1;
		}
		return eventQueue2;
	}
	
	/** Returns the event queue from which events should be inspected in the particular cycle. */
	private Queue<Event> getProcessQueue() {
		if (processQueue) {
			return eventQueue1;
		}
		return eventQueue2;
	}
	
	/** Changes event queues and initiating a cycle run. */
	@Override
	public void runCycle() {
		changeEventQueues();
		runComponent();
	}
	
	/** Changes the insert queue and initiates a run. */
	public void runAndRechangeInsertQueue() {
		// First the insert queue is changed back, so self-event sending can work
	    changeInsertQueue();
	    runComponent();
	}
	
	/**get the sender*/
	public LinkedList<String> getSenders(){
		return senders;
	}
	
	/** add possible sender*/
	public void addSender(String s) {
		senders.add(s);
	}
	
	/** set the current sender*/
	public void setSender (String s) {
		sender = s;
	}
	
	/** check if there is any possible sender*/
	public boolean isSender() {
		if(senders.size()==0) {
			return true;
		}
		else return false;
	}
	
	/** add a new possible receiver*/
	public void addReceiver(String c, String p) {
		String [] temp = new String [2];
		temp[0]=c;
		temp[1]=p;
		receivers.add(temp);
	}
	
	/** check last receiver*/
	public boolean lastReceiver(String c) {
		String port="";
		if(!send.isEmpty()) {
			for (int i = 0; i < receivers.size(); i++) {
				if(receivers.get(i)[1].equals(c)) {
					port=receivers.get(i)[2];
				}
			}
			if(port.equals(send.get(0))) {
				return true;
			}
			else return false;
		}
		return false;
	}
	
	/** delete last receiver, because the event were processed*/
	public void deleteLastReceiver() {
		if(!send.isEmpty()) {
			send.removeFirst();
		}
	}
	
	/** set the logger*/
	public void setLogger(Loging l) {
		this.l = l;
	}
	
	/** search for current active state*/
	public String getActiveState() {
		String state = "";
		String [] split = null;
		for(State s : org.yakindu.scr.controller.ControllerStatemachine.State.values()) {
			if(isStateActive(s)) {
				split = s.toString().split("_");
			}
		}
		state = split[split.length-1];
		
		return state;
	}
	
	/** returns with the last message*/
	public String getMessages(){
		return messages;
	}
	
	/** loging event*/
	public void LogEvent(String message) {
		l.WriteInFile(message);
		if(messages.isEmpty()) {
			messages = messages + message;
		}
		else messages = messages + ";"+ message;
	}
	
	/** Initiates a cycle run without changing the event queues. It is needed if this component is contained (wrapped) by another component.
	Should be used only be the container (composite system) class. */
	public void runComponent() {
		messages="";
		Queue<Event> eventQueue = getProcessQueue();
		while (!eventQueue.isEmpty()) {
				Event event = eventQueue.remove();
				switch (event.getEvent()) {
					case "PoliceInterrupt.Police": 
						LogEvent("out:"+sender+" in:"+name +" message:"+ event.getEvent());
						controllerStatemachine.getSCIPoliceInterrupt().raisePolice();
					break;
					default:
						throw new IllegalArgumentException("No such event!");
				}
		}
		controllerStatemachine.runCycle();
	}    		
	
	// Inner classes representing Ports
	public class SecondaryPolice implements PoliceInterruptInterface.Provided {
		private List<PoliceInterruptInterface.Listener.Provided> registeredListeners = new LinkedList<PoliceInterruptInterface.Listener.Provided>();


		@Override
		public boolean isRaisedPolice() {
			return controllerStatemachine.getSCISecondaryPolice().isRaisedPolice();
		}
		@Override
		public void registerListener(final PoliceInterruptInterface.Listener.Provided listener) {
			registeredListeners.add(listener);
			controllerStatemachine.getSCISecondaryPolice().getListeners().add(new SCISecondaryPoliceListener() {
				@Override
				public void onPoliceRaised() {
					send.add("SecondaryPolice");
					listener.raisePolice();
				}
			});
		}
		
		@Override
		public List<PoliceInterruptInterface.Listener.Provided> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public SecondaryPolice getSecondaryPolice() {
		return secondaryPolice;
	}
	
	public class PriorityControl implements ControlInterface.Provided {
		private List<ControlInterface.Listener.Provided> registeredListeners = new LinkedList<ControlInterface.Listener.Provided>();


		@Override
		public boolean isRaisedToggle() {
			return controllerStatemachine.getSCIPriorityControl().isRaisedToggle();
		}
		@Override
		public void registerListener(final ControlInterface.Listener.Provided listener) {
			registeredListeners.add(listener);
			controllerStatemachine.getSCIPriorityControl().getListeners().add(new SCIPriorityControlListener() {
				@Override
				public void onToggleRaised() {
					send.add("PriorityControl");
					listener.raiseToggle();
				}
			});
		}
		
		@Override
		public List<ControlInterface.Listener.Provided> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public PriorityControl getPriorityControl() {
		return priorityControl;
	}
	
	public class SecondaryControl implements ControlInterface.Provided {
		private List<ControlInterface.Listener.Provided> registeredListeners = new LinkedList<ControlInterface.Listener.Provided>();


		@Override
		public boolean isRaisedToggle() {
			return controllerStatemachine.getSCISecondaryControl().isRaisedToggle();
		}
		@Override
		public void registerListener(final ControlInterface.Listener.Provided listener) {
			registeredListeners.add(listener);
			controllerStatemachine.getSCISecondaryControl().getListeners().add(new SCISecondaryControlListener() {
				@Override
				public void onToggleRaised() {
					send.add("SecondaryControl");
					listener.raiseToggle();
				}
			});
		}
		
		@Override
		public List<ControlInterface.Listener.Provided> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public SecondaryControl getSecondaryControl() {
		return secondaryControl;
	}
	
	public class PoliceInterrupt implements PoliceInterruptInterface.Required {
		private List<PoliceInterruptInterface.Listener.Required> registeredListeners = new LinkedList<PoliceInterruptInterface.Listener.Required>();

		@Override
		public void raisePolice() {
			getInsertQueue().add(new Event("PoliceInterrupt.Police", null));
		}

		@Override
		public void registerListener(final PoliceInterruptInterface.Listener.Required listener) {
			registeredListeners.add(listener);
		}
		
		@Override
		public List<PoliceInterruptInterface.Listener.Required> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public PoliceInterrupt getPoliceInterrupt() {
		return policeInterrupt;
	}
	
	public class PriorityPolice implements PoliceInterruptInterface.Provided {
		private List<PoliceInterruptInterface.Listener.Provided> registeredListeners = new LinkedList<PoliceInterruptInterface.Listener.Provided>();


		@Override
		public boolean isRaisedPolice() {
			return controllerStatemachine.getSCIPriorityPolice().isRaisedPolice();
		}
		@Override
		public void registerListener(final PoliceInterruptInterface.Listener.Provided listener) {
			registeredListeners.add(listener);
			controllerStatemachine.getSCIPriorityPolice().getListeners().add(new SCIPriorityPoliceListener() {
				@Override
				public void onPoliceRaised() {
					send.add("PriorityPolice");
					listener.raisePolice();
				}
			});
		}
		
		@Override
		public List<PoliceInterruptInterface.Listener.Provided> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public PriorityPolice getPriorityPolice() {
		return priorityPolice;
	}
	
	/** Checks whether the wrapped statemachine is in the given state. */
	public boolean isStateActive(State state) {
		return controllerStatemachine.isStateActive(state);
	}
	
	public void setTimer(ITimer timer) {
		controllerStatemachine.setTimer(timer);
		reset();
	}
	
}
