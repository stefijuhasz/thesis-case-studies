package hu.bme.mit.gamma.impl.trafficlightctrl;

import java.util.Queue;
import java.util.List;
import java.util.LinkedList;

import hu.bme.mit.gamma.impl.event.*;
import hu.bme.mit.gamma.impl.interfaces.*;
import hu.bme.mit.gamma.impl.logandcontrol.Loging;

import org.yakindu.scr.trafficlightctrl.ITrafficLightCtrlStatemachine.SCILightCommandsListener;
import org.yakindu.scr.TimerService;
import org.yakindu.scr.ITimer;
import org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine;
import org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State;

public class TrafficLightCtrlStatechart implements TrafficLightCtrlStatechartInterface {
	// The wrapped Yakindu statemachine
	private TrafficLightCtrlStatemachine trafficLightCtrlStatemachine = new TrafficLightCtrlStatemachine();
	// Port instances
	private Control control = new Control();
	private PoliceInterrupt policeInterrupt = new PoliceInterrupt();
	private LightCommands lightCommands = new LightCommands();
	// Indicates which queues are active in this cycle
	private boolean insertQueue = true;
	private boolean processQueue = false;
	// Event queues for the synchronization of statecharts
	private Queue<Event> eventQueue1 = new LinkedList<Event>();
	private Queue<Event> eventQueue2 = new LinkedList<Event>();
	
	private String name;
	private Loging l;
	
	private String messages = "";
	private String sender = null;
	
	private LinkedList<String> senders = new LinkedList<String>();
	private LinkedList<String []> receivers = new LinkedList<String[]>();
	
	private LinkedList<String> send = new LinkedList<String>();
	
	public TrafficLightCtrlStatechart(String n) {
		// Initializing and entering the wrapped statemachine
		name = n;
		trafficLightCtrlStatemachine.setTimer(new TimerService());
	}
	
	/** Resets the statemachine. Should be used only be the container (composite system) class. */
	@Override
	public void reset() {
		trafficLightCtrlStatemachine.init();
		trafficLightCtrlStatemachine.enter();
	}
	
	/** Changes the event queues of the component instance. Should be used only be the container (composite system) class. */
	public void changeEventQueues() {
		insertQueue = !insertQueue;
		processQueue = !processQueue;
	}
	
	/** Changes the event queues to which the events are put. Should be used only be a cascade container (composite system) class. */
	public void changeInsertQueue() {
	    insertQueue = !insertQueue;
	}
	
	/** Returns whether the eventQueue containing incoming messages is empty. Should be used only be the container (composite system) class. */
	public boolean isEventQueueEmpty() {
		return getInsertQueue().isEmpty();
	}
	
	/** Returns the event queue into which events should be put in the particular cycle. */
	private Queue<Event> getInsertQueue() {
		if (insertQueue) {
			return eventQueue1;
		}
		return eventQueue2;
	}
	
	/** Returns the event queue from which events should be inspected in the particular cycle. */
	private Queue<Event> getProcessQueue() {
		if (processQueue) {
			return eventQueue1;
		}
		return eventQueue2;
	}
	
	/** Changes event queues and initiating a cycle run. */
	@Override
	public void runCycle() {
		changeEventQueues();
		runComponent();
	}
	
	/** Changes the insert queue and initiates a run. */
	public void runAndRechangeInsertQueue() {
		// First the insert queue is changed back, so self-event sending can work
	    changeInsertQueue();
	    runComponent();
	}
	
	/**get the sender*/
	public LinkedList<String> getSenders(){
		return senders;
	}
	
	/** add possible sender*/
	public void addSender(String s) {
		senders.add(s);
	}
	
	/** set the current sender*/
	public void setSender (String s) {
		sender = s;
	}
	
	/** check if there is any possible sender*/
	public boolean isSender() {
		if(senders.size()==0) {
			return true;
		}
		else return false;
	}
	
	/** add a new possible receiver*/
	public void addReceiver(String c, String p) {
		String [] temp = new String [2];
		temp[0]=c;
		temp[1]=p;
		receivers.add(temp);
	}
	
	/** check last receiver*/
	public boolean lastReceiver(String c) {
		String port="";
		if(!send.isEmpty()) {
			for (int i = 0; i < receivers.size(); i++) {
				if(receivers.get(i)[1].equals(c)) {
					port=receivers.get(i)[2];
				}
			}
			if(port.equals(send.get(0))) {
				return true;
			}
			else return false;
		}
		return false;
	}
	
	/** delete last receiver, because the event were processed*/
	public void deleteLastReceiver() {
		if(!send.isEmpty()) {
			send.removeFirst();
		}
	}
	
	/** set the logger*/
	public void setLogger(Loging l) {
		this.l = l;
	}
	
	/** search for current active state*/
	public String getActiveState() {
		String state = "";
		String [] split = null;
		for(State s : org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values()) {
			if(isStateActive(s)) {
				split = s.toString().split("_");
			}
		}
		state = split[split.length-1];
		
		return state;
	}
	
	/** returns with the last message*/
	public String getMessages(){
		return messages;
	}
	
	/** loging event*/
	public void LogEvent(String message) {
		l.WriteInFile(message);
		if(messages.isEmpty()) {
			messages = messages + message;
		}
		else messages = messages + ";"+ message;
	}
	
	/** Initiates a cycle run without changing the event queues. It is needed if this component is contained (wrapped) by another component.
	Should be used only be the container (composite system) class. */
	public void runComponent() {
		messages ="";
		Queue<Event> eventQueue = getProcessQueue();
		while (!eventQueue.isEmpty()) {
				Event event = eventQueue.remove();
				switch (event.getEvent()) {
					case "Control.Toggle": 
						LogEvent("out:"+sender+" in:"+name +" message:"+ event.getEvent());
						trafficLightCtrlStatemachine.getSCIControl().raiseToggle();
					break;
					case "PoliceInterrupt.Police": 
						LogEvent("out:"+sender+" in:"+name +" message:"+ event.getEvent());
						trafficLightCtrlStatemachine.getSCIPoliceInterrupt().raisePolice();
					break;
					default:
						throw new IllegalArgumentException("No such event!");
				}
		}
		trafficLightCtrlStatemachine.runCycle();
	}    		
	
	// Inner classes representing Ports
	public class Control implements ControlInterface.Required {
		private List<ControlInterface.Listener.Required> registeredListeners = new LinkedList<ControlInterface.Listener.Required>();

		@Override
		public void raiseToggle() {
			getInsertQueue().add(new Event("Control.Toggle", null));
		}

		@Override
		public void registerListener(final ControlInterface.Listener.Required listener) {
			registeredListeners.add(listener);
		}
		
		@Override
		public List<ControlInterface.Listener.Required> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public Control getControl() {
		return control;
	}
	
	public class PoliceInterrupt implements PoliceInterruptInterface.Required {
		private List<PoliceInterruptInterface.Listener.Required> registeredListeners = new LinkedList<PoliceInterruptInterface.Listener.Required>();

		@Override
		public void raisePolice() {
			getInsertQueue().add(new Event("PoliceInterrupt.Police", null));
		}

		@Override
		public void registerListener(final PoliceInterruptInterface.Listener.Required listener) {
			registeredListeners.add(listener);
		}
		
		@Override
		public List<PoliceInterruptInterface.Listener.Required> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public PoliceInterrupt getPoliceInterrupt() {
		return policeInterrupt;
	}
	
	public class LightCommands implements LightCommandsInterface.Provided {
		private List<LightCommandsInterface.Listener.Provided> registeredListeners = new LinkedList<LightCommandsInterface.Listener.Provided>();


		@Override
		public boolean isRaisedDisplayNone() {
			return trafficLightCtrlStatemachine.getSCILightCommands().isRaisedDisplayNone();
		}
		@Override
		public boolean isRaisedDisplayGreen() {
			return trafficLightCtrlStatemachine.getSCILightCommands().isRaisedDisplayGreen();
		}
		@Override
		public boolean isRaisedDisplayYellow() {
			return trafficLightCtrlStatemachine.getSCILightCommands().isRaisedDisplayYellow();
		}
		@Override
		public boolean isRaisedDisplayRed() {
			return trafficLightCtrlStatemachine.getSCILightCommands().isRaisedDisplayRed();
		}
		@Override
		public void registerListener(final LightCommandsInterface.Listener.Provided listener) {
			registeredListeners.add(listener);
			trafficLightCtrlStatemachine.getSCILightCommands().getListeners().add(new SCILightCommandsListener() {
				@Override
				public void onDisplayNoneRaised() {
					send.add("LightCommands");
					listener.raiseDisplayNone();
				}
				
				@Override
				public void onDisplayGreenRaised() {
					send.add("LightCommands");
					listener.raiseDisplayGreen();
				}
				
				@Override
				public void onDisplayYellowRaised() {
					send.add("LightCommands");
					listener.raiseDisplayYellow();
				}
				
				@Override
				public void onDisplayRedRaised() {
					send.add("LightCommands");
					listener.raiseDisplayRed();
				}
			});
		}
		
		@Override
		public List<LightCommandsInterface.Listener.Provided> getRegisteredListeners() {
			return registeredListeners;
		}

	}
	
	@Override
	public LightCommands getLightCommands() {
		return lightCommands;
	}
	
	/** Checks whether the wrapped statemachine is in the given state. */
	public boolean isStateActive(State state) {
		return trafficLightCtrlStatemachine.isStateActive(state);
	}
	
	public void setTimer(ITimer timer) {
		trafficLightCtrlStatemachine.setTimer(timer);
		reset();
	}
	
}
