package hu.bme.mit.gamma.impl.tutorial;

import hu.bme.mit.gamma.impl.interfaces.LightCommandsInterface;
import hu.bme.mit.gamma.impl.interfaces.PoliceInterruptInterface;

public interface CrossroadInterface {
	
	LightCommandsInterface.Provided getPriorityOutput();
	PoliceInterruptInterface.Required getPolice();
	LightCommandsInterface.Provided getSecondaryOutput();
	
	void reset();
	
	void runCycle();
	void runFullCycle();
	
} 
