package hu.bme.mit.gamma.impl.createuml;

/** class for Attribute*/
public class Attribute {
	
	private String id, name, type;
	
	public Attribute(String i, String n, String t) {
		id = i;
		name = n;
		type = t;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getAttribute() {
		String out = "<ownedAttribute xmi:id=\""+id+"\" name=\""+name+"\" type=\""+type+"\"/>";
		return out;
	}

}
