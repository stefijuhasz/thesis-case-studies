package hu.bme.mit.gamma.impl.createuml;

/** class for Behavior*/
public class Behavior {
	
	String type;
	int id;
	String name;
	
	public Behavior(int id, String name) {
		type="uml:OpaqueBehavior";
		this.id = id;
		this.name = name;
	}
	
	public String getBehavior() {
		return "<ownedBehavior xmi:type=\""+type+"\" xmi:id=\"behav"+id+"\" name=\""+name+"\"/>";
	}
	
	public String getId() {
		return "behav"+id;
	}

}
