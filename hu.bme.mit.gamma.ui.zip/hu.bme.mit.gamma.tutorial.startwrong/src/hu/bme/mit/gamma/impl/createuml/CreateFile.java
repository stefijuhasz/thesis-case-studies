package hu.bme.mit.gamma.impl.createuml;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.LinkedList;

public class CreateFile {
	
	/** creating the XML file*/
	public void create(String filename, LinkedList<String> output) {
		
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(filename,false));
			bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			bw.newLine();
			bw.write("<uml:Model xmi:version=\"20131001\" xmlns:xmi=\"http://www.omg.org/spec/XMI/20131001\" xmlns:uml=\"http://www.eclipse.org/uml2/5.0.0/UML\" xmi:id=\"_ChGtcN7zEeijQdeF859UKA\" name=\"NewModel\">");
			bw.newLine();
			bw.write("<packagedElement xmi:type=\"uml:Actor\" xmi:id=\"user\" name=\"User\"/>");
			bw.newLine();
			bw.write("<packagedElement xmi:type=\"uml:Class\" xmi:id=\"statechart\" name=\"Statechart\"/>");
			bw.newLine();
			bw.newLine();
			bw.write(" <packagedElement xmi:type=\"uml:Interaction\" xmi:id=\"interact\" name=\"NewModel\">");
			bw.newLine();
			
			
			for(int i =0;i<output.size();i++) {
				bw.write("\t"+output.get(i));
				bw.newLine();
			}
			bw.write("  </packagedElement>");
			bw.newLine();
			bw.write("</uml:Model>");

			bw.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
