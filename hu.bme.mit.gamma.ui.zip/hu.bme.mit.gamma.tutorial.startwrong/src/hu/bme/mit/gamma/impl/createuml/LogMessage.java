package hu.bme.mit.gamma.impl.createuml;

/** class for LogMessage*/
public class LogMessage {
	
	private String out, in, message;

	public String getOut() {
		return out;
	}

	public void setOut(String out) {
		this.out = out;
	}

	public String getIn() {
		return in;
	}

	public void setIn(String in) {
		this.in = in;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
