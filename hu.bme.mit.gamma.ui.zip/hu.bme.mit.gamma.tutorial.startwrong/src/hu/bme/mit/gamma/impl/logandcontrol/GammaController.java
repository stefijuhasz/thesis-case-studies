package hu.bme.mit.gamma.impl.logandcontrol;

import java.net.URL;
import java.util.ResourceBundle;

import hu.bme.mit.gamma.impl.createuml.CreateXML;
import hu.bme.mit.gamma.impl.tutorial.Crossroad;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Window;

public class GammaController implements Initializable{
	
	private Crossroad cc;
	private Loging l;	
	
	@FXML
    private Button bControllerPoliceInterrupt;

    @FXML
    private TextArea taControllerOutput;
    
    @FXML
    private TextArea taControllerStates;
    
    @FXML
    private TextArea taPrimaryLightOutput;
    
    @FXML
    private TextArea taPrimaryLightStates;
    
    @FXML
    private TextArea taSecondaryLightOutput;
    
    @FXML
    private TextArea taSecondaryLightStates;
    
    @FXML
    private TextArea taTestOutput;
    
    @FXML
    private TextArea taTestStates;
    
    @FXML
    private Button bPrimaryLightPoliceInterrupt;
    
    @FXML
    private Button bPrimaryLightControl;
    
    @FXML
    private Button bSecondaryLightPoliceInterrupt;
    
    @FXML
    private Button bSecondaryLightControl;
    
    @FXML
    private Button bStart;
    
    @FXML
    private Button bContinue;
    
    @FXML
    private Button bStop;
        
    @FXML
    private TextArea taLogs;

 
    
    @FXML
    protected void handleControllerPoliceInterrupt(ActionEvent event) {
    	cc.getController().getPoliceInterrupt().raisePolice();
    	
    	
    }
    
    @FXML
    protected void handlePrimaryLightPoliceInterrupt(ActionEvent event) {
    	Window owner = bPrimaryLightPoliceInterrupt.getScene().getWindow();
    	
    }
    
    @FXML
    protected void handlePrimaryLightControl(ActionEvent event) {
    	Window owner = bPrimaryLightControl.getScene().getWindow();
    	
    }
    
    @FXML
    protected void handleSecondaryLightPoliceInterrupt(ActionEvent event) {
    	Window owner = bSecondaryLightPoliceInterrupt.getScene().getWindow();
    	
    }
    
    @FXML
    protected void handleSecondaryLightControl(ActionEvent event) {
    	Window owner = bSecondaryLightControl.getScene().getWindow();
    	
    }
    
    @FXML
    protected void handleStart(ActionEvent event) {
    	l.WriteInFile("Starting...");
		cc.reset();
		
		setLogger(cc.getMessages());
		updateStates();
    	
    }
    
    @FXML
    protected void handleContinue(ActionEvent event) {
    	cc.runCycle();
		
		setLogger(cc.getMessages());
		updateStates();
    	
    }

    @FXML
    protected void handleStop(ActionEvent event) {
    	l.WriteInFile("Exiting...");
		new CreateXML().start();
		System.exit(0);
    	
    }
       
   

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		cc = new Crossroad();
		l = new Loging("CommunicationLog");
		cc.setLogger(l);
		
		taControllerOutput.setText("SecondaryPolice\n");
		taControllerOutput.appendText("PriorityControl\n");
		taControllerOutput.appendText("SecondaryControl\n");
		taControllerOutput.appendText("PriorityPolice");
		
		
		taPrimaryLightOutput.setText("LightCommands");
		
		taSecondaryLightOutput.setText("LightCommands");
	}
	
	public void setLogger(String messages) {
		taLogs.setText(messages);
	}
	
	public void updateStates() {
		String states = "";
		String activeState = cc.getController().getActiveState();
		int count = 0;
		for(org.yakindu.scr.controller.ControllerStatemachine.State s : org.yakindu.scr.controller.ControllerStatemachine.State.values()) {
			String[] split = s.toString().split("_");
			count++;
			if(activeState.equals(split[split.length-1])) {
				states = states + "<"+split[split.length-1]+">\n";
			}
			else if(count < org.yakindu.scr.controller.ControllerStatemachine.State.values().length-1) { 
				states = states +split[split.length-1]+"\n";
			}
			else if(count == org.yakindu.scr.controller.ControllerStatemachine.State.values().length-1) {
				states = states +split[split.length-1];
			}
		}
		
		taControllerStates.setText(states);
		states = "";
		activeState=cc.getPrior().getActiveState();
		count = 0;
		for(org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State s : org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values()) {
			String[] split = s.toString().split("_");
			count++;
			if(activeState.equals(split[split.length-1])) {
				states = states + "<"+split[split.length-1]+">\n";
			}
			else if(count < org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values().length-1) {
				states = states +split[split.length-1]+"\n";
			}
			else if(count == org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values().length-1) {
				states = states +split[split.length-1];
			}
		}
		
		taPrimaryLightStates.setText(states);
		
		states = "";
		activeState=cc.getSecondary().getActiveState();
		count = 0;
		for(org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State s : org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values()) {
			String[] split = s.toString().split("_");
			count++;
			if(activeState.equals(split[split.length-1])) {
				states = states + "<"+split[split.length-1]+">\n";
			}
			else if(count < org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values().length-1) {
				states = states +split[split.length-1]+"\n";
			}
			else if(count == org.yakindu.scr.trafficlightctrl.TrafficLightCtrlStatemachine.State.values().length-1) {
				states = states +split[split.length-1];
			}
			
		}
		taSecondaryLightStates.setText(states);
	}

}
