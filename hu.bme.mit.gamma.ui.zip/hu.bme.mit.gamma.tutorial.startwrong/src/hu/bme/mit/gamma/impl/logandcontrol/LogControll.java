package hu.bme.mit.gamma.impl.logandcontrol;

import hu.bme.mit.gamma.impl.createuml.CreateXML;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LogControll extends Application{
	
	/** starting point*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Parent root = FXMLLoader.load(getClass().getResource("gamma_ui.fxml"));
        primaryStage.setTitle("Gamma Controller");
        primaryStage.setScene(new Scene(root, 1280, 500));
        primaryStage.show();      
		
	}
	
	@Override
	public void stop(){
		new CreateXML().start();
		System.exit(0);
	}

}
