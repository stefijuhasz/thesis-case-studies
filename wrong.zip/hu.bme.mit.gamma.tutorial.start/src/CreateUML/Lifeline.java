package CreateUML;

/** class for Lifeline*/
public class Lifeline {
	
	String id;
	String name;
	String rep;
	String cover;
	int covernum;
	
	public Lifeline(String id, String name, String rep, String cover) {
		this.id=id;
		this.name = name;
		this.rep = rep;
		this.cover = cover;
		covernum =0;
	}
	
	public void addCover(int n) {
		covernum = covernum+n;
	}
	
	public int getNum() {
		return covernum;
	}
	
	public String getCover() {
		return cover;
	}
	public String getName() {
		return name;
	}
	
	public String getId() {
		return id;
	}
	
	public String getLifeline() {
		String out="<lifeline xmi:id=\""+id+"\" name=\""+name+"\" represents=\""+rep+"\" ";
		if(covernum>0) {
			out=out+"coveredBy=\"";
			for(int i=0;i<covernum;i++) {
				out=out+cover+(i+1)+" ";
			}
			out=out+"\"";
		}
		out=out+"/>";
		return out;
	}

}
