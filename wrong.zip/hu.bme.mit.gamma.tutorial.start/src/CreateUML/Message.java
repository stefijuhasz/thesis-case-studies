package CreateUML;

/** class for creating Message*/
import java.util.LinkedList;
import java.util.List;

public class Message {
	
	LinkedList<String> fragment = new LinkedList<String>();
	String message;
	
	public void addFragment(String s) {
		fragment.add(s);
	}
	
	public void createFragments(String sender, String receiver, String execute, String execution, String name, String lifeline1, String lifeline2, String message, String behav) {
		String frag = "<fragment xmi:type=\"uml:MessageOccurrenceSpecification\" xmi:id=\""+sender+"\" name=\""+name+"_sender\" covered=\""+lifeline1+"\" message=\""+message+"\"/>";
		addFragment(frag);
		frag = "<fragment xmi:type=\"uml:MessageOccurrenceSpecification\" xmi:id=\""+receiver+"\" name=\""+name+"_receiver\" covered=\""+lifeline2+"\" message=\""+message+"\"/>";
		addFragment(frag);
		frag="<fragment xmi:type=\"uml:BehaviorExecutionSpecification\" xmi:id=\""+execute+"\" name=\""+name+"\" covered=\""+lifeline2+"\" finish=\""+execution+"\" start=\""+receiver+"\" behavior=\""
				+ behav+"\"/>";
		addFragment(frag);
		frag = "<fragment xmi:type=\"uml:ExecutionOccurrenceSpecification\" xmi:id=\""+execution+"\" name=\""+name+"_finish\" covered=\""+lifeline2+"\" execution=\""+execute+"\"/>";
		addFragment(frag);
	}
	
	public void createMessage(String id, String name,String receiver, String send) {
		message="<message xmi:id=\"message"+id+"\" name=\""+name+"\" messageSort=\"asynchCall\" receiveEvent=\""+receiver+"\" sendEvent=\""+send+"\" signature=\"\"/>";
	}
	
	public LinkedList<String> getFragment(){
		return fragment;
	}
	
	public String getMessage() {
		return message;
	}

}
