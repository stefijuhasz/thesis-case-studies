package LogAndControll;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedList;

public class GCDParser {
	
	/** parsing the components from given file*/
	@SuppressWarnings("resource")
	public LinkedList<String> parseComponent(String filename){
		LinkedList<String> components = new LinkedList<String>();
		File f = new File(filename);
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String s = "";
			while((s = br.readLine()) != null) {
				String [] split = s.split("\\ |\\t|\\,");
				if(split.length>1 && split[1].equals("component")) {
					String add="";
					for(int i =2;i<split.length;i++) {
						add =add + split[i];
					}
					components.add(add);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return components;
	}
	
	/** parsing the states from given file*/
	@SuppressWarnings("resource")
	public LinkedList<String> parseState(String filename){
		LinkedList<String> states = new LinkedList<String>();
		File f = new File(filename);
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String s = "";
			while((s = br.readLine()) != null) {
				String [] split = s.split("\\ |\\t|\\,");
				if(split.length>2 && split[2].equals("state")) {
					states.add(split[3].toString());
				}
				if(split.length>4 && split[4].equals("state")) {
					states.add(split[5].toString());
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return states;
	}
	
	/**parsing the ports from given file*/
	@SuppressWarnings("resource")
	public LinkedList<Port> parsePort(String filename){
		LinkedList<Port> ports = new LinkedList<Port>();
		File f = new File(filename);
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String s = "";
			while((s = br.readLine()) != null) {
				String [] split = s.split("\\ |\\t|\\,");
				if(split.length>1 && split[1].equals("port")) {
					ports.add(new Port(split[2].toString(),split[4].toString()));
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ports;
	}

}
