package LogAndControll;


import hu.bme.mit.gamma.impl.tutorial.Crossroad;

public class LogControll {
	
	/** starting point*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Crossroad cc = new Crossroad();
		GammaView gv = new GammaView();
		Loging l = new Loging("CommunitationLog");
		cc.setLogger(l);
		Control c = new Control(gv,cc,l);
		
		c.init();
		
		
		
	}

}
