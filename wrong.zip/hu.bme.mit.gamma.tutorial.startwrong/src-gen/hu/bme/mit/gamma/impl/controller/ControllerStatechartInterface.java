package hu.bme.mit.gamma.impl.controller;

import hu.bme.mit.gamma.impl.interfaces.PoliceInterruptInterface;
import hu.bme.mit.gamma.impl.interfaces.ControlInterface;

public interface ControllerStatechartInterface {
	
	PoliceInterruptInterface.Required getPoliceInterrupt();
	PoliceInterruptInterface.Provided getPriorityPolice();
	ControlInterface.Provided getSecondaryControl();
	PoliceInterruptInterface.Provided getSecondaryPolice();
	ControlInterface.Provided getPriorityControl();
	
	void reset();
	
	void runCycle();
	
} 
