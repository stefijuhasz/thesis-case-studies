package org.yakindu.scr.monitor;

import org.yakindu.scr.IStatemachine;

public interface IMonitorStatemachine extends IStatemachine {

	public interface SCILightInputs {
	
		public void raiseDisplayRed();
		
		public void raiseDisplayGreen();
		
		public void raiseDisplayYellow();
		
		public void raiseDisplayNone();
		
	}
	
	public SCILightInputs getSCILightInputs();
	
}
