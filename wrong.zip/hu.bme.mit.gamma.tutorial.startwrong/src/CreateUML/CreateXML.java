package CreateUML;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class CreateXML {
	
	/** create data for the XML file */
	public void start() {
		LinkedList<LogMessage> lm = new LinkedList<LogMessage>();
		LinkedList<Lifeline> l = new LinkedList<Lifeline>();
		LinkedList<Attribute> a = new LinkedList<Attribute>();
		LinkedList<Behavior> b = new LinkedList<Behavior>();
		LinkedList<Message> mes = new LinkedList<Message>();
		
		
		File f = new File("logger.log");
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String s = "";
			while((s = br.readLine()) != null) {
				int counter =0;
				LogMessage m = new LogMessage();
				String [] split = s.split(" ");
				for(int i = 0;i<split.length;i++) {
					if(split[i].contains("out")) {
						String [] temp = split[i].split(":");
						if(temp.length>1) {
							m.setOut(temp[1]);
							counter++;
						}
					}
					if(split[i].contains("in")) {
						String [] temp = split[i].split(":");
						if(temp.length>1) {
							m.setIn(temp[1]);
							counter++;
						}
					}
					if(split[i].contains("message")) {
						String [] temp = split[i].split(":");
						if(temp.length>1) {
							m.setMessage(temp[1]);
							counter++;
						}
					}
					if(counter==3) {
						lm.add(m);
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		LinkedList<String> component = new LinkedList<String>();
		for(int i = 0;i<lm.size();i++) {
			if(!component.contains(lm.get(i).getOut())){
				component.add(lm.get(i).getOut());
			}
			if(!component.contains(lm.get(i).getIn())){
				component.add(lm.get(i).getIn());
			}
		}
		
		int countstatechart = 1;
		
		for(int i=0;i<component.size();i++) {
			
			if(component.get(i).toLowerCase().equals("user")) {
				Lifeline l1 = new Lifeline(component.get(i)+"lifeline",component.get(i),"useratt","usercover");
				Attribute a1 = new Attribute("useratt",component.get(i),"user");
				l.add(l1);
				a.add(a1);
			}
			else {
				Lifeline l2 = new Lifeline(component.get(i)+"lifeline",component.get(i),"statechartatt"+countstatechart,component.get(i)+"cover");
				Attribute a2 = new Attribute("statechartatt"+countstatechart,component.get(i),"statechart");
				l.add(l2);
				a.add(a2);
				countstatechart++;
			}
		}
		
		String send="";
		String receiv ="";
		String exec ="";
		String exect ="";
		String l1="";
		String l2="";
		
		for (int i = 0; i < lm.size(); i++) {
			int k = i;
			for (int j = 0; j < l.size(); j++) {
				if(lm.get(i).getOut().toLowerCase().equals(l.get(j).getName().toLowerCase())) {
					l.get(j).addCover(1);
					send = l.get(j).getCover()+l.get(j).getNum();
					l1 = l.get(j).getId();
				}
				if(lm.get(i).getIn().toLowerCase().equals(l.get(j).getName().toLowerCase())) {
					l.get(j).addCover(3);
					receiv = l.get(j).getCover()+(l.get(j).getNum()-2);
					exec = l.get(j).getCover()+(l.get(j).getNum()-1);
					exect = l.get(j).getCover()+(l.get(j).getNum());
					l2 = l.get(j).getId();
				}
			}
			Behavior beh = new Behavior(i+1,lm.get(i).getMessage());
			b.add(beh);
			Message mtemp = new Message();
			String mestemp = "message" +(i+1);
			mtemp.createMessage(Integer.toString(i+1), lm.get(i).getMessage(), receiv, send);
			mtemp.createFragments(send, receiv, exec, exect, lm.get(i).getMessage(), l1, l2, mestemp, beh.getId());
			mes.add(mtemp);
			i=k;
		}
		
		
		
		LinkedList<String> output = new LinkedList<String>();
		
		for (int i = 0; i < a.size(); i++) {
			output.add(a.get(i).getAttribute());
		}
		
		for(int i = 0;i<b.size();i++) {
			output.add(b.get(i).getBehavior());
		}
		
		
		for (int i =0;i<l.size();i++) {
			output.add(l.get(i).getLifeline());
		}
		
		for(int i=0;i<mes.size();i++) {
			output.addAll(mes.get(i).getFragment());
		}
		
		for(int i =0;i<mes.size();i++) {
			output.add(mes.get(i).getMessage());
		}
		
		if(lm.size()>0) {
		
			CreateFile cf = new CreateFile();
			cf.create("model.uml", output);
			System.out.println("K�sz a f�jl!");
			
			try {
				Desktop desktop = null;
				if (Desktop.isDesktopSupported()) {
			        desktop = Desktop.getDesktop();
			      }
	
			       desktop.open(new File("model.uml"));
			    } catch (IOException ioe) {
			      ioe.printStackTrace();
			}
		}
	}

}
