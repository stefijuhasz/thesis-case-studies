package LogAndControll;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.LinkedList;

import javax.swing.JButton;

import CreateUML.CreateXML;
import hu.bme.mit.gamma.impl.tutorial.Crossroad;

public class Control {
	
	private GammaView gw;
	private Crossroad cc;
	private Loging l;
	private GCDParser p = new GCDParser();
	private JButton policeButton1 = null;
	private JButton controlButton1 = null;
	private JButton policeButton2 = null;
	private JButton controlButton2 = null;
	private JButton policeButton3 = null;
		
	
	
	public Control(GammaView g, Crossroad c, Loging log) {
		gw = g;
		cc = c;
		l = log;
	}
	
	/** initialize the UI and the controls*/
	public void init() {
		
		setNameLabels();
		setStates();
		setPorts();
		
		gw.startButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				l.WriteInFile("Starting...");
				cc.reset();
				
				setLogger(cc.getMessages());
				updateStates();
				gw.stopButton.setEnabled(true);
				gw.continueButton.setEnabled(true);
				policeButton1.setEnabled(true);
			}
			
		});
		gw.stopButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				l.WriteInFile("Exiting...");
				new CreateXML().start();
				System.exit(0);
			}
			
		});
		gw.continueButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				cc.runCycle();
				
				setLogger(cc.getMessages());
				updateStates();
				
			}
			
		});
		gw.showEventDemo();
	}
	
	public void updateStates() {
		LinkedList<String> states = p.parseState("model\\Controller\\Controller.gcd");
		String s ="<html>";
		String controllerState = cc.getController().getActiveState();
		for (int i=0;i<states.size();i++) {
			if(controllerState.equals(states.get(i))) {
				s = s+"<i>&lt;"+states.get(i)+"&gt;</i>"+"<br>";
			}
			else s = s+states.get(i)+"<br>";
		}
		s = s +"</html>";
		gw.setFirstLabel2(s);
		states = p.parseState("model\\TrafficLight\\TrafficLightCtrl.gcd");
		s ="<html>";
		String priorState = cc.getPrior().getActiveState();
		for (int i=0;i<states.size();i++) {
			if(priorState.equals(states.get(i))) {
				s = s+"<i>&lt;"+states.get(i)+"&gt;</i>"+"<br>";
			}
			else s = s+states.get(i)+"<br>";
		}
		s = s +"</html>";
		gw.setSecondLabel2(s);
		
		s ="<html>";
		String secondaryState = cc.getSecondary().getActiveState();
		for (int i=0;i<states.size();i++) {
			if(secondaryState.equals(states.get(i))) {
				s = s+"<i>&lt;"+states.get(i)+"&gt;</i>"+"<br>";
			}
			else s = s+states.get(i)+"<br>";
		}
		s = s +"</html>";
		
		gw.setThirdLabel2(s);
	}
	
	public void setNameLabels() {
		LinkedList<String> component = p.parseComponent("model\\Crossroad.gcd");
		for(int i = 0; i < component.size(); i++) {
			switch(i) {
			case 0:
				gw.setFirtsLabel(component.get(i));
				break;
			case 1:
				gw.setSecondLabel(component.get(i));
				break;
			case 2:
				gw.setThirdLabel(component.get(i));
				break;
			default:
				break;
			}
		}
	}
	
	public void setPorts() {
		LinkedList<Port> ports = p.parsePort("model\\Controller\\Controller.gcd");
		String output = "<html>";
		for(int i=0;i<ports.size();i++) {
			if(ports.get(i).getType().equals("provides")) {
				output = output + ports.get(i).getName()+"<br>";
			}
		}
		gw.setFirstLabel1(output);
		
		LinkedList<Port> req = new LinkedList<Port>();
		for(int i = 0;i<ports.size();i++) {
			if(ports.get(i).getType().equals("requires")) {
				req.add(ports.get(i));
			}
		}
		
		
		for(int i = 0;i<req.size();i++) {
			switch(i) {
				case 0:
					policeButton1 = new JButton(req.get(i).getName());
					gw.firstPanel.add(policeButton1);
					break;
				default:
					break;
			}
		}
		
		policeButton1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				cc.getController().getPoliceInterrupt().raisePolice();
				/*cc.runCycle();
				setLogger(cc.getMessages());
				updateStates();*/
			}
			
		});
		
		policeButton1.setEnabled(false);
		
		ports = p.parsePort("model\\TrafficLight\\TrafficLightCtrl.gcd");
		output = "<html>";
		for(int i=0;i<ports.size();i++) {
			if(ports.get(i).getType().equals("provides")) {
				output = output + ports.get(i).getName()+"<br>";
			}
		}
		gw.setSecondLabel1(output);
		
		LinkedList<Port> req1 = new LinkedList<Port>();
		for(int i = 0;i<ports.size();i++) {
			if(ports.get(i).getType().equals("requires")) {
				req1.add(ports.get(i));
			}
		}
		
		
		for(int i = 0;i<req1.size();i++) {
			switch(i) {
				case 0:
					controlButton1 = new JButton(req1.get(i).getName());
					gw.secondPanel.add(controlButton1);
					break;
				case 1:
					policeButton2 = new JButton(req1.get(i).getName());
					gw.secondPanel.add(policeButton2);
				default:
					break;
			}
		}
		controlButton1.setEnabled(false);
		policeButton2.setEnabled(false);
		
	
		
		for(int i = 0;i<req1.size();i++) {
			switch(i) {
				case 0:
					controlButton2 = new JButton(req1.get(i).getName());
					gw.thirdPanel.add(controlButton2);
					break;
				case 1:
					policeButton3 = new JButton(req1.get(i).getName());
					gw.thirdPanel.add(policeButton3);
				default:
					break;
			}
		}
		controlButton2.setEnabled(false);
		policeButton3.setEnabled(false);
		
		gw.setThirdLabel1(output);
	}
	
	public void setStates() {
		LinkedList<String> states = p.parseState("model\\Controller\\Controller.gcd");
		String s ="<html>";
		for (int i=0;i<states.size();i++) {
			s = s+states.get(i)+"<br>";
		}
		s = s +"</html>";
		gw.setFirstLabel2(s);
		states = p.parseState("model\\TrafficLight\\TrafficLightCtrl.gcd");
		s ="<html>";
		for (int i=0;i<states.size();i++) {
			s = s+states.get(i)+"<br>";
		}
		s = s +"</html>";
		gw.setSecondLabel2(s);
		gw.setThirdLabel2(s);
	}
	
	
	public void setLogger(String messages) {
		
		gw.setLog(messages);
	}
}
