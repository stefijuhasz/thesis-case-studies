package LogAndControll;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

public class Loging {

		private Logger l;
		
		public Loging(String name) {
			/**configure layout*/
			PatternLayout layout = new PatternLayout();
	        String conversionPattern = "%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n";
	        layout.setConversionPattern(conversionPattern);
	 
	        /**configure appenders*/
	        ConsoleAppender consoleAppender = new ConsoleAppender();
	        consoleAppender.setLayout(layout);
	        consoleAppender.activateOptions();
	 
	        FileAppender fileAppender = new FileAppender();
	        fileAppender.setFile("logger.log");
	        fileAppender.setLayout(layout);
	        fileAppender.setAppend(false);
	        fileAppender.activateOptions();
	 
	        /**configure logger*/
	        l = Logger.getLogger(name);
	        l.setLevel(Level.INFO);
	        l.addAppender(consoleAppender);
	        l.addAppender(fileAppender);
		}
		
		public void WriteInFile(String message) {
			l.info(message);
		}
}